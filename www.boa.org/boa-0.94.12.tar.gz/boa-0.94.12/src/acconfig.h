/* define if GUNZIP found */
#undef GUNZIP

/* sockaddr_in has sin_len member */
#undef HAVE_SIN_LEN

/* how many times we shift left for unsigned long */
#undef NEEDS_ESCAPE_SHIFT

/* if struct tm has tm_gmtoff structure */
#undef HAVE_TM_GMTOFF

/* if struct tm has tm_zone structure */
#undef HAVE_TM_ZONE

